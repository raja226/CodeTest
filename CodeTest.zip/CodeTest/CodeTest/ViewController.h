//
//  ViewController.h
//  CodeTest
//
//  Created by RAJASEKHAR GOGULA on 16/04/18.
//  Copyright © 2018 CodeTest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

